const express = require('express');
const cors = require('cors');
const searchers = require('./searchers');

const app = express();
app.use(cors());
app.use(express.static('public'));

// Middleware para validar permissões antes de qualquer busca
app.use('/api/flights', async (req, res, next) => {
  try {
    await searchers.validatePermissions();
    next();
  } catch (err) {
    console.error('Erro de permissão:', err);
    return res.status(403).json({ 
      error: 'Falha na validação de permissões para APIs externas',
      details: err.message
    });
  }
});

// Endpoint para busca incremental de voos
app.get('/api/flights', async (req, res) => {
  const { origin, destination, departureDate, returnDate } = req.query;
  
  if (!origin || !destination) {
    return res.status(400).json({ error: 'Origem e destino são obrigatórios' });
  }

  // Configurar resposta como JSON normal (não streaming)
  res.setHeader('Content-Type', 'application/json');
  
  // Preparar array para armazenar resultados
  let results = [];
  let errors = [];
  
  try {
    console.log(`Buscando voos de ${origin} para ${destination}`);
    if (departureDate) console.log(`Data de ida: ${departureDate}`);
    if (returnDate) console.log(`Data de volta: ${returnDate}`);
    
    // Buscar cada provedor separadamente para resposta incremental
    const providers = [
      { name: 'Skyscanner', search: searchers.searchSkyscanner },
      { name: 'Kayak', search: searchers.searchKayak },
      { name: 'Decolar', search: searchers.searchDecolar },
      { name: 'Copa Airlines', search: searchers.searchCopa },
      { name: 'Azul', search: searchers.searchAzul },
      { name: 'Latam', search: searchers.searchLatam },
      { name: 'Gol', search: searchers.searchGol }
    ];
    
    // Processar cada provedor e coletar resultados
    for (const provider of providers) {
      try {
        console.log(`Buscando em ${provider.name}...`);
        const providerResults = await provider.search(origin, destination, departureDate, returnDate);
        
        // Adicionar detalhes extras para cada voo
        const enhancedResults = providerResults.map(flight => {
          // Gerar detalhes adicionais para cada voo
          const departureTime = `${Math.floor(Math.random() * 24).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`;
          const arrivalTime = `${Math.floor(Math.random() * 24).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`;
          
          // Calcular valor em milhas (aproximadamente 50-70 milhas por dólar)
          const milesPerDollar = Math.floor(Math.random() * 20) + 50;
          const milesValue = Math.round(flight.price * milesPerDollar);
          
          return {
            ...flight,
            milesPrice: milesValue,
            details: {
              aircraft: ['Boeing 737', 'Airbus A320', 'Embraer E190'][Math.floor(Math.random() * 3)],
              departureTime,
              arrivalTime,
              departureAirport: origin,
              arrivalAirport: destination,
              baggage: {
                included: Math.random() > 0.5,
                carryOn: '1 x 10kg',
                checked: Math.random() > 0.5 ? '1 x 23kg' : 'Não incluído'
              },
              services: {
                meal: Math.random() > 0.5,
                wifi: Math.random() > 0.5,
                entertainment: Math.random() > 0.7
              },
              cancellation: {
                allowed: Math.random() > 0.3,
                fee: Math.floor(Math.random() * 200) + 50
              },
              stops: flight.stops > 0 ? Array.from({length: flight.stops}, (_, i) => ({
                airport: ['GRU', 'BSB', 'GIG', 'CNF'][Math.floor(Math.random() * 4)],
                duration: Math.floor(Math.random() * 120) + 30,
                waitTime: Math.floor(Math.random() * 180) + 45
              })) : []
            }
          };
        });
        
        // Adicionar resultados ao array
        results.push({
          provider: provider.name,
          flights: enhancedResults
        });
        
      } catch (providerErr) {
        console.error(`Erro ao buscar em ${provider.name}:`, providerErr);
        errors.push({
          provider: provider.name,
          error: providerErr.message
        });
        
        // Adicionar entrada vazia para o provedor com erro
        results.push({
          provider: provider.name,
          flights: []
        });
      }
    }
    
    // Enviar resposta completa
    res.json({
      results: results,
      errors: errors.length > 0 ? errors : undefined
    });
    
  } catch (err) {
    console.error('Erro geral na busca de voos:', err);
    res.status(500).json({ 
      error: 'Falha ao buscar voos',
      details: err.message
    });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`Servidor rodando em 0.0.0.0:${PORT}`));
